# Roadmap

🇬🇧 English | 🇩🇪 Deutsch weiter unten

Planned ideas for upcoming versions. The focus is on **Linux** (KDE Plasma). The order is rough, not binding. More ideas are welcome as an [issue](https://github.com/RembrandtZ4/NeoNote-Media-Player/issues/new/choose).

## Version 1.2 – released 2026-11-20
- [x] **Videos via mpv** – rendering on the GPU: smooth 4K, HDR on regular screens, image subtitles (PGS/VobSub) from Blu-rays and DVDs
- [x] **Resume where you left off** for audiobooks, podcasts and long videos, chapter navigation
- [x] **Sleep timer** (“after 30 minutes”, “after this album”)
- [x] **Smart playlists** with custom rules (e.g. “80s rock, at least 4 stars, not played for 3 months”) – like in Windows Media Player 12
- [x] **Lyrics**, synced in “Now playing” mode (e.g. via LRCLIB) and from the files themselves
- [x] **Transparent dialogs** (settings, equalizer …) with their own title bar and the same blur as the main window – one continuous surface on Windows and KDE
- [x] **Flatpak** – for Ubuntu, Fedora, Mint and other distributions (Flathub listing to follow)

## Version 1.3 – released 2026-11-23
- [x] **Crossfade** between tracks
- [x] **Playback speed** for audiobooks and videos
- [x] **Audio output selection** and bit-perfect playback (e.g. for external DACs)
- [x] **Folder view** – browse your music folders
- [x] **Rename and organize files** using patterns like “Artist/Album/No. Title”
- [x] **Scrobbling** to Last.fm and ListenBrainz
- [x] **Artist info** in “Now playing” – biography and similar artists
- [x] **Visualization** like in Windows Media Player
- [x] **Auto DJ** – endless matching music from your own collection
- [x] **Star ratings in the music files** (WMP-compatible)

## Version 1.3.2 – released 2026-11-26
- [x] **Faster start** – quick-start cache for the library, instant start screen and optional preloading at login (starts hidden in the tray, the window then appears instantly)
- [x] **Open music and videos with NeoNote** like VLC – pick the formats in the installer and in the settings
- [x] **Beta channel** – try test versions early, on Windows and as an Arch zip
- [x] **Safe mode and crash report** – if something goes wrong at start, NeoNote helps itself and shows a report to copy
- [x] **What's new after an update**, animated dialogs, and the uninstaller can remove personal data on request

## Version 1.3.3 – released 2026-11-27
- [x] **Casting** to DLNA/UPnP, Chromecast and AirPlay devices (TVs, speakers, AV receivers), with one-click firewall setup
- [x] **8 new languages:** French, Spanish, Italian, Dutch, Polish, Portuguese (Brazil), Russian, Turkish

## Next
- [ ] **Jellyfin security:** store the access token in the system's password store (Windows Credential Manager, KWallet) and warn before signing in over unencrypted `http://` outside the home network
- [ ] **AUR package** – install with `yay -S neonote` (ready; waiting for AUR registration to reopen)
- [ ] **Native Wayland** with KDE's own blur (sharper with fractional scaling)
- [ ] **Flathub** listing

## Later
- [ ] **Casting extras:** AirPlay 2 pairing and format conversion for devices that can't play a file
- [ ] **Remote control** – control NeoNote on the PC from your phone via a simple web page on the home network (no app needed)

## Ideas
*Most of these will be optional and stay out of the way until you turn them on – NeoNote should keep its tidy WMP12 look.*

- [ ] **Features page** in the settings – turn whole features on or off (Jellyfin, radio, casting, lyrics, visualization …); what's off disappears completely
- [ ] **Podcasts** – subscribe, download new episodes automatically, resume where you left off
- [ ] **Rip CDs** like in WMP12, with track names from MusicBrainz
- [ ] **Listening stats** – top artists, listening time per week, a small year in review
- [ ] **Calculate ReplayGain** values yourself instead of only using existing ones
- [ ] **Custom background image** behind the glass – a photo, or the current album cover blurred
- [ ] **Font and font size** for the interface
- [ ] **Compact or roomy view** – row height and spacing in lists
- [ ] **Adjustable corner rounding** – from square to strongly rounded
- [ ] **Save and share themes** – keep your own color combinations as presets and pass them on as a file
- [ ] **Customizable control bar** – which buttons are shown and in which order
- [ ] **Custom keyboard shortcuts**
- [ ] **Customizable “Now playing”** – cover size, lyrics left or right, choice of visualization
- [ ] **Mini player variants** – cover only, slim bar, or with lyrics
- [ ] **Media streaming (server)** – share the library in the home network so TVs and receivers can browse and play it, like WMP12
- [ ] **Sync** music to phone, USB stick or MP3 player – optionally automatic by playlist
- [ ] **Convert files** – e.g. FLAC to MP3/Opus for phone or car, whole albums at once
- [ ] **Headphone correction (AutoEQ)** – pick your headphone model and the equalizer evens out its sound
- [ ] **Advanced search** – filters like genre, year range and rating right in the search box
- [ ] **Sound analysis** – BPM, mood and energy; similar-sounding tracks and an Auto DJ that mixes by sound
- [ ] **Audiobook mode** – bookmarks, chapters and progress per book

## Earlier
- [x] **Updater for Windows** – install new versions right from NeoNote *(since 1.1.8)*

---

# Roadmap (Deutsch)

Geplante Ideen für kommende Versionen. Der Schwerpunkt liegt auf **Linux** (KDE Plasma). Die Reihenfolge ist grob, nicht verbindlich. Weitere Wünsche gern als [Issue](https://github.com/RembrandtZ4/NeoNote-Media-Player/issues/new/choose).

## Version 1.2 – erschienen am 20.11.2026
- [x] **Videos über mpv** – Darstellung auf der Grafikkarte: flüssiges 4K, HDR auf normalen Bildschirmen, Bild-Untertitel (PGS/VobSub) von Blu-rays und DVDs
- [x] **Weiterhören an der letzten Stelle** bei Hörbüchern, Podcasts und langen Videos, Kapitelsprünge
- [x] **Einschlaf-Timer** („nach 30 Minuten“, „nach diesem Album“)
- [x] **Intelligente Wiedergabelisten** mit eigenen Regeln (z. B. „Rock aus den 80ern, mindestens 4 Sterne, seit 3 Monaten nicht gespielt“) – wie in Windows Media Player 12
- [x] **Songtexte**, zeitgesteuert im „Wird gespielt“-Modus (z. B. über LRCLIB) und aus den Dateien selbst
- [x] **Transparente Dialoge** (Einstellungen, Equalizer …) mit eigener Titelleiste und demselben Weichzeichner wie das Hauptfenster – eine durchgehende Fläche unter Windows und KDE
- [x] **Flatpak** – für Ubuntu, Fedora, Mint und andere Distributionen (Aufnahme in Flathub folgt später)

## Version 1.3 – erschienen am 23.11.2026
- [x] **Überblenden** zwischen Titeln
- [x] **Wiedergabegeschwindigkeit** für Hörbücher und Videos
- [x] **Eigene Audioausgabe** und bitgenaue Wiedergabe (z. B. für externe DACs)
- [x] **Ordneransicht** – durch die Musikordner stöbern
- [x] **Dateien umbenennen und einsortieren** nach Mustern wie „Interpret/Album/Nr. Titel“
- [x] **Scrobbeln** zu Last.fm und ListenBrainz
- [x] **Infos zum Interpreten** in „Wird gespielt“ – Biografie und ähnliche Künstler
- [x] **Visualisierung** wie im Windows Media Player
- [x] **Auto-DJ** – endlos passende Musik aus der eigenen Sammlung
- [x] **Sternbewertungen in den Musikdateien** (kompatibel mit WMP)

## Version 1.3.2 – erschienen am 26.11.2026
- [x] **Schnellerer Start** – Schnellstart-Speicher für die Bibliothek, sofortiges Startbild und auf Wunsch Vorladen beim Anmelden (startet unsichtbar im Infobereich, das Fenster erscheint dann sofort)
- [x] **Musik und Videos mit NeoNote öffnen** wie bei VLC – Formate im Installer und in den Einstellungen wählbar
- [x] **Beta-Kanal** – Testversionen früh ausprobieren, unter Windows und als Arch-Zip
- [x] **Sicherer Modus und Absturzbericht** – geht beim Start etwas schief, hilft sich NeoNote selbst und zeigt einen Bericht zum Kopieren
- [x] **Neuerungen nach einem Update**, animierte Dialoge, und der Deinstaller entfernt auf Wunsch die persönlichen Daten

## Version 1.3.3 – erschienen am 27.11.2026
- [x] **Streamen** zu DLNA/UPnP-, Chromecast- und AirPlay-Geräten (Fernseher, Lautsprecher, AV-Receiver), Firewall-Freigabe per Klick
- [x] **8 neue Sprachen:** Französisch, Spanisch, Italienisch, Niederländisch, Polnisch, Portugiesisch (Brasilien), Russisch, Türkisch

## Als Nächstes
- [ ] **Jellyfin-Sicherheit:** den Zugangsschlüssel im Passwortspeicher des Systems ablegen (Windows-Anmeldeinformationsverwaltung, KWallet) und vor einer Anmeldung über unverschlüsseltes `http://` außerhalb des Heimnetzes warnen
- [ ] **AUR-Paket** – Installation mit `yay -S neonote` (fertig vorbereitet; wartet darauf, dass das AUR die Registrierung wieder öffnet)
- [ ] **Natives Wayland** mit dem Weichzeichner von KDE (schärfer bei krummer Skalierung)
- [ ] **Aufnahme in Flathub**

## Später
- [ ] **Streamen, Ausbau:** AirPlay-2-Kopplung und Formatumwandlung für Geräte, die eine Datei nicht abspielen können
- [ ] **Fernbedienung** – NeoNote am PC vom Handy aus steuern, über eine einfache Webseite im Heimnetz (ohne App)

## Ideen
*Das meiste davon wird optional und bleibt unauffällig, bis man es einschaltet – NeoNote soll aufgeräumt bleiben wie der WMP12.*

- [ ] **Seite „Funktionen“** in den Einstellungen – ganze Funktionen ein- und ausschalten (Jellyfin, Radio, Streamen, Songtexte, Visualisierung …); was aus ist, verschwindet komplett
- [ ] **Podcasts** – abonnieren, neue Folgen automatisch laden, an der letzten Stelle weiterhören
- [ ] **CDs rippen** wie im WMP12, mit Titeln von MusicBrainz
- [ ] **Hör-Statistik** – meistgehörte Interpreten, Hörzeit pro Woche, ein kleiner Jahresrückblick
- [ ] **ReplayGain selbst berechnen**, statt nur vorhandene Werte zu nutzen
- [ ] **Eigenes Hintergrundbild** hinter dem Glas – ein Foto oder das aktuelle Albumcover verschwommen
- [ ] **Schriftart und Schriftgröße** für die Oberfläche
- [ ] **Kompakte oder großzügige Ansicht** – Zeilenhöhe und Abstände in den Listen
- [ ] **Eckenrundung einstellbar** – von eckig bis stark gerundet
- [ ] **Designs speichern und teilen** – eigene Farb-Kombinationen als Vorlage sichern und als Datei weitergeben
- [ ] **Steuerleiste anpassen** – welche Knöpfe zu sehen sind und in welcher Reihenfolge
- [ ] **Tastenkürzel selbst festlegen**
- [ ] **„Wird gespielt“ gestalten** – Cover groß oder klein, Songtext links oder rechts, Visualisierung wählen
- [ ] **Mini-Player-Varianten** – nur Cover, schmale Leiste oder mit Songtext
- [ ] **Medienstreaming (Server)** – die Bibliothek im Heimnetz freigeben, damit Fernseher und Receiver darin stöbern und abspielen können, wie beim WMP12
- [ ] **Synchronisieren** – Musik auf Handy, USB-Stick oder MP3-Player kopieren, auf Wunsch automatisch nach Wiedergabeliste
- [ ] **Dateien umwandeln** – z. B. FLAC in MP3/Opus fürs Handy oder Auto, ganze Alben auf einmal
- [ ] **Kopfhörer-Korrektur (AutoEQ)** – Kopfhörermodell wählen, der Equalizer gleicht dessen Klang aus
- [ ] **Erweiterte Suche** – Filter wie Genre, Jahresbereich und Bewertung direkt im Suchfeld
- [ ] **Klang-Analyse** – BPM, Stimmung und Energie; ähnlich klingende Titel und ein Auto-DJ, der nach Klang mischt
- [ ] **Hörbuch-Modus** – Lesezeichen, Kapitel und Fortschritt pro Buch

## Früher
- [x] **Updater für Windows** – neue Versionen direkt aus NeoNote installieren *(seit 1.1.8)*
